
BASE_URL = 'https://www.jumia.ug/'
